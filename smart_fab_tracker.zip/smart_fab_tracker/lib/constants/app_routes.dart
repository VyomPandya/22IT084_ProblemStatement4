class AppRoutes {
  // Auth routes
  static const String splash = '/splash';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  
  // Main app routes
  static const String home = '/home';
  
  // Material routes
  static const String materials = '/materials';
  static const String addMaterial = '/add-material';
  static const String editMaterial = '/edit-material';
  static const String materialDetails = '/material-details';
  
  // Product routes
  static const String products = '/products';
  static const String addProduct = '/add-product';
  static const String editProduct = '/edit-product';
  static const String productDetails = '/product-details';
  
  // Scanning routes
  static const String scanMaterial = '/scan-material';
  static const String consumptionLog = '/consumption-log';
  
  // Reports routes
  static const String reports = '/reports';
  static const String inventoryReport = '/inventory-report';
  static const String consumptionReport = '/consumption-report';
  static const String exportData = '/export-data';
  
  // User management routes
  static const String profile = '/profile';
  static const String userManagement = '/user-management';
  static const String editUser = '/edit-user';
} 