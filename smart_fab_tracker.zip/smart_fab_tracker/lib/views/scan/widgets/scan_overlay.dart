import 'package:flutter/material.dart';

import '../../../constants/app_theme.dart';

class ScanOverlay extends StatelessWidget {
  const ScanOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return ColorFiltered(
      colorFilter: ColorFilter.mode(
        Colors.black.withOpacity(0.5),
        BlendMode.srcOut,
      ),
      child: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              color: Colors.transparent,
              backgroundBlendMode: BlendMode.dstOut,
            ),
            child: Center(
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          // Scan box border effect
          Center(
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                border: Border.all(
                  color: AppTheme.primaryColor,
                  width: 3,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          // Corner markers
          Center(
            child: SizedBox(
              width: 250,
              height: 250,
              child: Stack(
                children: [
                  // Top left corner
                  _buildCornerMarker(Alignment.topLeft),
                  // Top right corner
                  _buildCornerMarker(Alignment.topRight),
                  // Bottom left corner
                  _buildCornerMarker(Alignment.bottomLeft),
                  // Bottom right corner
                  _buildCornerMarker(Alignment.bottomRight),
                ],
              ),
            ),
          ),
          // Scan animation line
          Center(
            child: ScanAnimationLine(
              width: 230, 
              height: 250,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCornerMarker(Alignment alignment) {
    final isTop = alignment == Alignment.topLeft || alignment == Alignment.topRight;
    final isLeft = alignment == Alignment.topLeft || alignment == Alignment.bottomLeft;
    
    return Align(
      alignment: alignment,
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          border: Border(
            top: isTop ? const BorderSide(color: AppTheme.primaryColor, width: 4) : BorderSide.none,
            bottom: !isTop ? const BorderSide(color: AppTheme.primaryColor, width: 4) : BorderSide.none,
            left: isLeft ? const BorderSide(color: AppTheme.primaryColor, width: 4) : BorderSide.none,
            right: !isLeft ? const BorderSide(color: AppTheme.primaryColor, width: 4) : BorderSide.none,
          ),
        ),
      ),
    );
  }
}

// Scanning animation line
class ScanAnimationLine extends StatefulWidget {
  final double width;
  final double height;

  const ScanAnimationLine({
    super.key,
    required this.width,
    required this.height,
  });

  @override
  State<ScanAnimationLine> createState() => _ScanAnimationLineState();
}

class _ScanAnimationLineState extends State<ScanAnimationLine> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    _animation = Tween<double>(
      begin: 0,
      end: widget.height,
    ).animate(_animationController)
      ..addListener(() {
        setState(() {});
      });

    _animationController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: _animation.value - 2, // -2 to adjust for line width
      child: Container(
        width: widget.width,
        height: 4,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.transparent,
              AppTheme.primaryColor.withOpacity(0.8),
              Colors.transparent,
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
      ),
    );
  }
} 