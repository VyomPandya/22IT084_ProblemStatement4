import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../constants/app_routes.dart';
import '../../constants/app_theme.dart';
import '../../models/material_model.dart';
import '../../services/scanner_service.dart';
import '../../services/material_service.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final TextEditingController _manualCodeController = TextEditingController();
  bool _isScanning = false;

  @override
  void initState() {
    super.initState();
    // Start scanner service
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final scannerService = Provider.of<ScannerService>(context, listen: false);
      scannerService.startScanning();
    });
  }

  @override
  void dispose() {
    _manualCodeController.dispose();
    super.dispose();
  }

  // Handle manual barcode entry
  Future<void> _processManualEntry() async {
    final barcode = _manualCodeController.text.trim();
    if (barcode.isEmpty) return;

    final scannerService = Provider.of<ScannerService>(context, listen: false);
    final material = await scannerService.processManualBarcode(barcode);
    
    if (material != null) {
      _navigateToConsumptionScreen(material);
    }
  }

  // Navigate to consumption log screen with scanned material
  void _navigateToConsumptionScreen(MaterialModel material) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Material found: ${material.name}')),
    );
  }

  // Simulate a scan with predetermined barcode
  Future<void> _simulateScan() async {
    setState(() {
      _isScanning = true;
    });
    
    try {
      // Simulate camera processing time
      await Future.delayed(Duration(seconds: 1));
      
      final scannerService = Provider.of<ScannerService>(context, listen: false);
      
      // Try a known barcode from our mock data
      final material = await scannerService.simulateScan('STEEL-5MM-001');
      
      if (material != null) {
        _navigateToConsumptionScreen(material);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isScanning = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Material'),
      ),
      body: Consumer<ScannerService>(
        builder: (context, scannerService, _) {
          final errorMessage = scannerService.scanError;
          final scannedMaterial = scannerService.scannedMaterial;
          
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Error message
                if (errorMessage.isNotEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 16),
                    color: Colors.red.withOpacity(0.1),
                    child: Row(
                      children: [
                        const Icon(Icons.error, color: Colors.red),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            errorMessage,
                            style: const TextStyle(color: Colors.red),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.red),
                          onPressed: () {
                            scannerService.resetScan();
                          },
                          iconSize: 16,
                        ),
                      ],
                    ),
                  ),
                
                // Scanned material result
                if (scannedMaterial != null)
                  Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            scannedMaterial.name,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          if (scannedMaterial.description != null)
                            Text(scannedMaterial.description!),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Text('Stock: ${scannedMaterial.currentStock} ${scannedMaterial.unitType.toString().split('.').last}'),
                              const Spacer(),
                              Text('Cost: \$${scannedMaterial.unitCost.toStringAsFixed(2)}'),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: () {
                                  scannerService.resetScan();
                                },
                                child: const Text('Cancel'),
                              ),
                              const SizedBox(width: 8),
                              ElevatedButton(
                                onPressed: () {
                                  _navigateToConsumptionScreen(scannedMaterial);
                                },
                                child: const Text('Log Consumption'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                
                // Mock scanner view
                Container(
                  height: 250,
                  margin: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: _isScanning 
                      ? const Center(
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : Stack(
                          alignment: Alignment.center,
                          children: [
                            const Icon(
                              Icons.qr_code_scanner,
                              size: 100,
                              color: Colors.white24,
                            ),
                            Positioned(
                              bottom: 16,
                              child: ElevatedButton(
                                onPressed: _simulateScan,
                                child: const Text('Simulate Scan'),
                              ),
                            ),
                          ],
                        ),
                ),
                
                const Text(
                  'Enter Material Barcode',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'You can manually enter a barcode or QR code value.',
                  style: TextStyle(
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 16),
                
                // Text field for manual entry
                TextField(
                  controller: _manualCodeController,
                  decoration: InputDecoration(
                    labelText: 'Barcode / QR Code',
                    hintText: 'Enter the code value',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.search),
                      onPressed: _processManualEntry,
                    ),
                  ),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _processManualEntry(),
                ),
                const SizedBox(height: 16),
                
                // Search button
                ElevatedButton.icon(
                  onPressed: _processManualEntry,
                  icon: const Icon(Icons.search),
                  label: const Text('Find Material'),
                ),
                
                const SizedBox(height: 24),
                const Text(
                  'Try these codes: STEEL-5MM-001, ALU-2MM-002, COPPER-12AWG-003',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
} 