import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../../../constants/app_routes.dart';
import '../../../constants/app_theme.dart';
import '../../../models/consumption_log_model.dart';
import '../../../services/auth_service.dart';
import '../../../services/material_service.dart';
import '../../../utils/format_utils.dart';

class OperatorDashboard extends StatefulWidget {
  const OperatorDashboard({super.key});

  @override
  State<OperatorDashboard> createState() => _OperatorDashboardState();
}

class _OperatorDashboardState extends State<OperatorDashboard> {
  bool _isLoading = true;
  List<ConsumptionLogModel> _recentLogs = [];
  
  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  // Load dashboard data
  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // In a real app, you would fetch recent logs from a service
      // For now, we'll create a dummy list of recent consumption logs
      await Future.delayed(const Duration(milliseconds: 500));
      
      final now = DateTime.now();
      final authService = Provider.of<AuthService>(context, listen: false);
      final operatorId = authService.currentUser?.id ?? '';
      final operatorName = authService.currentUser?.name ?? 'Operator';
      
      // Create dummy recent logs
      _recentLogs = [
        ConsumptionLogModel(
          id: '1',
          materialId: 'mat1',
          materialName: 'Steel Sheet',
          quantity: 5.0,
          unitCost: 12.50,
          unitType: 'sheet',
          productId: 'prod1',
          productName: 'Metal Cabinet',
          operatorId: operatorId,
          operatorName: operatorName,
          timestamp: now.subtract(const Duration(hours: 1, minutes: 30)),
          notes: 'Used for cabinet frames',
          isSynced: true,
        ),
        ConsumptionLogModel(
          id: '2',
          materialId: 'mat2',
          materialName: 'Paint (Blue)',
          quantity: 2.5,
          unitCost: 8.75,
          unitType: 'l',
          productId: 'prod1',
          productName: 'Metal Cabinet',
          operatorId: operatorId,
          operatorName: operatorName,
          timestamp: now.subtract(const Duration(hours: 2, minutes: 15)),
          notes: 'Final coating',
          isSynced: true,
        ),
        ConsumptionLogModel(
          id: '3',
          materialId: 'mat3',
          materialName: 'Aluminum Rivets',
          quantity: 50.0,
          unitCost: 0.15,
          unitType: 'piece',
          productId: 'prod2',
          productName: 'File Storage Unit',
          operatorId: operatorId,
          operatorName: operatorName,
          timestamp: now.subtract(const Duration(hours: 4, minutes: 45)),
          notes: 'Assembly',
          isSynced: true,
        ),
      ];
      
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading dashboard data: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final operatorName = authService.currentUser?.name ?? 'Operator';
    
    return RefreshIndicator(
      onRefresh: _loadDashboardData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Greeting and date
            Text(
              'Hello, $operatorName',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryColor,
                  ),
            ),
            Text(
              DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now()),
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppTheme.textSecondaryColor,
                  ),
            ),
            const SizedBox(height: 24),
            
            // Scan button
            _buildScanButton(),
            const SizedBox(height: 24),
            
            // Recent activity
            _buildRecentActivity(),
            const SizedBox(height: 24),
            
            // Quick links
            _buildQuickLinks(),
          ],
        ),
      ),
    );
  }

  // Scan button widget
  Widget _buildScanButton() {
    return InkWell(
      onTap: () {
        Navigator.of(context).pushNamed(AppRoutes.scanMaterial);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 24),
        decoration: BoxDecoration(
          color: AppTheme.primaryColor,
          borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
          boxShadow: [
            BoxShadow(
              color: AppTheme.primaryColor.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            const Icon(
              Icons.qr_code_scanner,
              color: Colors.white,
              size: 56,
            ),
            const SizedBox(height: 16),
            const Text(
              'SCAN MATERIAL',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Scan barcode or QR code to log material consumption',
              style: TextStyle(
                fontSize: 14,
                color: Colors.white.withOpacity(0.8),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Recent activity widget
  Widget _buildRecentActivity() {
    return Card(
      elevation: AppTheme.cardElevation,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Activity',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Icon(Icons.history, color: AppTheme.primaryColor),
              ],
            ),
            const Divider(),
            
            if (_isLoading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: CircularProgressIndicator(),
                ),
              )
            else if (_recentLogs.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Center(
                  child: Text(
                    'No recent activities found',
                    style: TextStyle(
                      color: AppTheme.textSecondaryColor,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              )
            else
              // List of recent logs
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _recentLogs.length,
                itemBuilder: (context, index) {
                  final log = _recentLogs[index];
                  return _buildActivityItem(log);
                },
              ),
            
            // View all button
            if (!_isLoading && _recentLogs.isNotEmpty)
              Center(
                child: TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushNamed(AppRoutes.consumptionHistory);
                  },
                  icon: const Icon(Icons.visibility),
                  label: const Text('View All Activities'),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  // Individual activity item
  Widget _buildActivityItem(ConsumptionLogModel log) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Material icon
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Center(
              child: Icon(
                Icons.inventory,
                color: AppTheme.primaryColor,
              ),
            ),
          ),
          const SizedBox(width: 12),
          
          // Activity details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        log.materialName,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      FormatUtils.formatTimeAgo(log.timestamp),
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondaryColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      '${FormatUtils.formatNumber(log.quantity)} ${log.unitType}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (log.productName != null) ...[
                      const Text(' • '),
                      Expanded(
                        child: Text(
                          log.productName!,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.textSecondaryColor,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                if (log.notes != null && log.notes!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(
                      log.notes!,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondaryColor,
                        fontStyle: FontStyle.italic,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  // Quick links widget
  Widget _buildQuickLinks() {
    return Card(
      elevation: AppTheme.cardElevation,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Quick Links',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              children: [
                _buildLinkCard(
                  'View Materials',
                  Icons.inventory,
                  AppTheme.primaryColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.materials),
                ),
                _buildLinkCard(
                  'Manual Entry',
                  Icons.edit,
                  AppTheme.secondaryColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.logConsumption),
                ),
                _buildLinkCard(
                  'My Profile',
                  Icons.person,
                  AppTheme.infoColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.userProfile),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  // Individual link card
  Widget _buildLinkCard(String title, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
} 