import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

import '../../../constants/app_routes.dart';
import '../../../constants/app_theme.dart';
import '../../../models/material_model.dart';
import '../../../services/material_service.dart';
import '../../../services/product_service.dart';
import '../../../utils/format_utils.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  bool _isLoading = true;
  double _totalMaterialValue = 0;
  int _totalMaterials = 0;
  int _lowStockItems = 0;
  
  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  // Load dashboard statistics
  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final materialService = Provider.of<MaterialService>(context, listen: false);
      final materials = materialService.materials;
      
      // Calculate total material value
      double totalValue = 0;
      int lowStockCount = 0;
      
      for (var material in materials) {
        totalValue += material.currentStock * material.unitCost;
        if (material.isLowStock()) {
          lowStockCount++;
        }
      }
      
      setState(() {
        _totalMaterialValue = totalValue;
        _totalMaterials = materials.length;
        _lowStockItems = lowStockCount;
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading dashboard data: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Get materials for the charts
    final materialService = Provider.of<MaterialService>(context);
    final materials = materialService.materials;
    
    return RefreshIndicator(
      onRefresh: _loadDashboardData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Greeting and date
            Text(
              'Admin Dashboard',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryColor,
                  ),
            ),
            Text(
              DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now()),
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppTheme.textSecondaryColor,
                  ),
            ),
            const SizedBox(height: 24),
            
            // Statistics cards
            if (_isLoading)
              const Center(
                child: CircularProgressIndicator(),
              )
            else
              _buildStatisticsCards(),
            
            const SizedBox(height: 24),
            
            // Low stock materials
            if (!_isLoading && _lowStockItems > 0) ...[
              _buildLowStockWarning(),
              const SizedBox(height: 24),
            ],
            
            // Material distribution chart
            if (!_isLoading && materials.isNotEmpty) ...[
              _buildMaterialChart(materials),
              const SizedBox(height: 24),
            ],
            
            // Quick actions
            _buildQuickActions(),
          ],
        ),
      ),
    );
  }

  // Statistics cards
  Widget _buildStatisticsCards() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: 1.5,
      children: [
        _buildStatCard(
          'Total Inventory Value',
          FormatUtils.formatCurrency(_totalMaterialValue),
          Icons.attach_money,
          AppTheme.primaryColor,
        ),
        _buildStatCard(
          'Total Materials',
          '$_totalMaterials',
          Icons.inventory,
          AppTheme.secondaryColor,
        ),
        _buildStatCard(
          'Low Stock Items',
          '$_lowStockItems',
          Icons.warning,
          _lowStockItems > 0 ? AppTheme.warningColor : AppTheme.successColor,
        ),
        _buildStatCard(
          'Last Sync',
          'Just now',
          Icons.sync,
          AppTheme.infoColor,
        ),
      ],
    );
  }
  
  // Individual statistic card
  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      elevation: AppTheme.cardElevation,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 14,
                      color: AppTheme.textSecondaryColor,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const Spacer(),
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  // Low stock warning section
  Widget _buildLowStockWarning() {
    final materialService = Provider.of<MaterialService>(context);
    final lowStockMaterials = materialService.getLowStockMaterials();
    
    return Card(
      elevation: AppTheme.cardElevation,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      ),
      color: AppTheme.warningColor.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.warning, color: AppTheme.warningColor),
                SizedBox(width: 8),
                Text(
                  'Low Stock Warning',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.warningColor,
                  ),
                ),
              ],
            ),
            const Divider(),
            const SizedBox(height: 8),
            // List of low stock items (show up to 3)
            ...lowStockMaterials.take(3).map((material) => Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      material.name,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  Text(
                    '${material.currentStock} ${material.unitDisplay} left',
                    style: const TextStyle(color: AppTheme.errorColor),
                  ),
                ],
              ),
            )),
            
            // Show more button if more than 3 low stock items
            if (lowStockMaterials.length > 3) ...[
              const Divider(),
              Center(
                child: TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushNamed(AppRoutes.materials);
                  },
                  icon: const Icon(Icons.visibility),
                  label: Text('Show all ${lowStockMaterials.length} low stock items'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
  
  // Material value distribution pie chart
  Widget _buildMaterialChart(List<MaterialModel> materials) {
    // Sort materials by value (stock * unit cost) and take top 5
    final sortedMaterials = [...materials];
    sortedMaterials.sort((a, b) => 
        (b.currentStock * b.unitCost).compareTo(a.currentStock * a.unitCost));
    
    final top5Materials = sortedMaterials.take(5).toList();
    
    // Calculate others
    double top5Value = 0;
    for (var material in top5Materials) {
      top5Value += material.currentStock * material.unitCost;
    }
    
    double othersValue = _totalMaterialValue - top5Value;
    
    // Generate sections for the pie chart
    List<PieChartSectionData> sections = [];
    
    // Color palette
    final colors = [
      AppTheme.primaryColor,
      AppTheme.secondaryColor,
      AppTheme.infoColor,
      AppTheme.successColor,
      AppTheme.warningColor,
      AppTheme.errorColor, // For "Others"
    ];
    
    // Add top 5 materials
    for (int i = 0; i < top5Materials.length; i++) {
      final material = top5Materials[i];
      final value = material.currentStock * material.unitCost;
      final percentage = (value / _totalMaterialValue) * 100;
      
      sections.add(
        PieChartSectionData(
          color: colors[i],
          value: value,
          title: '${percentage.toStringAsFixed(1)}%',
          radius: 100,
          titleStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      );
    }
    
    // Add others if relevant
    if (othersValue > 0) {
      final percentage = (othersValue / _totalMaterialValue) * 100;
      sections.add(
        PieChartSectionData(
          color: colors[5],
          value: othersValue,
          title: '${percentage.toStringAsFixed(1)}%',
          radius: 100,
          titleStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      );
    }
    
    return Card(
      elevation: AppTheme.cardElevation,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Inventory Value Distribution',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: PieChart(
                PieChartData(
                  sections: sections,
                  sectionsSpace: 2,
                  centerSpaceRadius: 40,
                  startDegreeOffset: 180,
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Legend
            Column(
              children: [
                ...top5Materials.asMap().entries.map((entry) {
                  final index = entry.key;
                  final material = entry.value;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: Row(
                      children: [
                        Container(
                          width: 16,
                          height: 16,
                          color: colors[index],
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            material.name,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Text(
                          FormatUtils.formatCurrency(material.currentStock * material.unitCost),
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  );
                }),
                if (othersValue > 0)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: Row(
                      children: [
                        Container(
                          width: 16,
                          height: 16,
                          color: colors[5],
                        ),
                        const SizedBox(width: 8),
                        const Expanded(
                          child: Text('Others'),
                        ),
                        Text(
                          FormatUtils.formatCurrency(othersValue),
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  // Quick actions section
  Widget _buildQuickActions() {
    return Card(
      elevation: AppTheme.cardElevation,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Quick Actions',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              children: [
                _buildActionCard(
                  'Add Material',
                  Icons.add_circle,
                  AppTheme.primaryColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.addMaterial),
                ),
                _buildActionCard(
                  'Scan Barcode',
                  Icons.qr_code_scanner,
                  AppTheme.secondaryColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.scanMaterial),
                ),
                _buildActionCard(
                  'View Reports',
                  Icons.bar_chart,
                  AppTheme.infoColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.reports),
                ),
                _buildActionCard(
                  'Add Product',
                  Icons.category,
                  AppTheme.successColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.addProduct),
                ),
                _buildActionCard(
                  'Export Data',
                  Icons.download,
                  AppTheme.secondaryColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.exportData),
                ),
                _buildActionCard(
                  'User Mgmt',
                  Icons.people,
                  AppTheme.warningColor,
                  () => Navigator.of(context).pushNamed(AppRoutes.userManagement),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  // Individual action card
  Widget _buildActionCard(String title, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppTheme.defaultBorderRadius),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
} 