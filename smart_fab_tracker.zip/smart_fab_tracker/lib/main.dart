import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/foundation.dart';

import 'constants/app_theme.dart';
import 'constants/app_routes.dart';
import 'services/auth_service.dart';
import 'services/material_service.dart';
import 'services/product_service.dart';
import 'services/report_service.dart';
import 'services/scanner_service.dart';
import 'views/auth/login_screen.dart';
import 'views/home/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Force HTML renderer for web
  if (kIsWeb) {
    // This is done automatically by the --web-renderer=html flag
    // but we're adding this comment for clarity
  }
  
  runApp(const SmartFabTracker());
}

class SmartFabTracker extends StatelessWidget {
  const SmartFabTracker({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // Auth service provider
        ChangeNotifierProvider(
          create: (_) => AuthService(),
          lazy: false,
        ),
        
        // Material service provider (depends on AuthService)
        ChangeNotifierProxyProvider<AuthService, MaterialService>(
          create: (context) => MaterialService(
            Provider.of<AuthService>(context, listen: false),
          ),
          update: (context, authService, previous) => 
            previous ?? MaterialService(authService),
        ),
        
        // Product service provider (depends on AuthService)
        ChangeNotifierProxyProvider<AuthService, ProductService>(
          create: (context) => ProductService(
            Provider.of<AuthService>(context, listen: false),
          ),
          update: (context, authService, previous) => 
            previous ?? ProductService(authService),
        ),
        
        // Scanner service provider (depends on MaterialService)
        ChangeNotifierProxyProvider<MaterialService, ScannerService>(
          create: (context) => ScannerService(
            Provider.of<MaterialService>(context, listen: false),
          ),
          update: (context, materialService, previous) => 
            previous ?? ScannerService(materialService),
        ),
        
        // Report service provider (depends on AuthService)
        Provider(
          create: (context) => ReportService(
            Provider.of<AuthService>(context, listen: false),
          ),
          lazy: true,
        ),
      ],
      child: MaterialApp(
        title: 'SmartFab Tracker',
        theme: AppTheme.getLightTheme(),
        darkTheme: AppTheme.getDarkTheme(),
        themeMode: ThemeMode.system,
        debugShowCheckedModeBanner: false,
        home: const LoginScreen(),
        routes: {
          AppRoutes.login: (context) => const LoginScreen(),
          AppRoutes.home: (context) => const HomeScreen(),
        },
      ),
    );
  }
}

// Observer to handle auth state navigation
class AuthNavigatorObserver extends NavigatorObserver {
  final AuthService _authService;
  
  AuthNavigatorObserver(this._authService);
  
  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    _checkAuthStatus(route);
    super.didPush(route, previousRoute);
  }
  
  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    if (newRoute != null) _checkAuthStatus(newRoute);
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
  }
  
  void _checkAuthStatus(Route<dynamic> route) {
    // Skip auth check for these routes
    final authExemptRoutes = [
      AppRoutes.splash,
      AppRoutes.login,
      AppRoutes.register,
      AppRoutes.forgotPassword,
    ];
    
    final routeName = route.settings.name;
    if (routeName == null) return;
    
    // If not logged in and trying to access a protected route, redirect to login
    if (!_authService.isLoggedIn && 
        !authExemptRoutes.contains(routeName) && 
        navigator != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        navigator!.pushReplacementNamed(AppRoutes.login);
      });
    }
  }
}
