// import 'package:cloud_firestore/cloud_firestore.dart';

class ConsumptionLogModel {
  final String id;
  final String materialId;
  final String materialName;
  final double quantity;
  final double unitCost;
  final String unitType;
  final String? productId; // Optional - if consumption is for a specific product
  final String? productName;
  final String operatorId;
  final String operatorName;
  final DateTime timestamp;
  final String? notes;
  final bool isSynced; // For offline caching
  final String? batchNumber;

  ConsumptionLogModel({
    required this.id,
    required this.materialId,
    required this.materialName,
    required this.quantity,
    required this.unitCost,
    required this.unitType,
    this.productId,
    this.productName,
    required this.operatorId,
    required this.operatorName,
    required this.timestamp,
    this.notes,
    this.isSynced = false,
    this.batchNumber,
  });

  // Factory constructor for demo data
  factory ConsumptionLogModel.fromMap(Map<String, dynamic> map) {
    return ConsumptionLogModel(
      id: map['id'] ?? '',
      materialId: map['materialId'] ?? '',
      materialName: map['materialName'] ?? '',
      quantity: (map['quantity'] ?? 0.0).toDouble(),
      unitCost: (map['unitCost'] ?? 0.0).toDouble(),
      unitType: map['unitType'] ?? '',
      productId: map['productId'],
      productName: map['productName'],
      operatorId: map['operatorId'] ?? '',
      operatorName: map['operatorName'] ?? '',
      timestamp: map['timestamp'] != null 
          ? (map['timestamp'] is int) 
              ? DateTime.fromMillisecondsSinceEpoch(map['timestamp']) 
              : DateTime.parse(map['timestamp'].toString())
          : DateTime.now(),
      notes: map['notes'],
      isSynced: map['isSynced'] ?? false,
      batchNumber: map['batchNumber'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'materialId': materialId,
      'materialName': materialName,
      'quantity': quantity,
      'unitCost': unitCost,
      'unitType': unitType,
      'productId': productId,
      'productName': productName,
      'operatorId': operatorId,
      'operatorName': operatorName,
      'timestamp': timestamp.toIso8601String(),
      'notes': notes,
      'isSynced': isSynced,
      'batchNumber': batchNumber,
    };
  }

  // For saving to local storage
  Map<String, dynamic> toLocalMap() {
    return {
      'id': id,
      'materialId': materialId,
      'materialName': materialName,
      'quantity': quantity,
      'unitCost': unitCost,
      'unitType': unitType,
      'productId': productId,
      'productName': productName,
      'operatorId': operatorId,
      'operatorName': operatorName,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'notes': notes,
      'isSynced': isSynced,
      'batchNumber': batchNumber,
    };
  }

  ConsumptionLogModel copyWith({
    String? id,
    String? materialId,
    String? materialName,
    double? quantity,
    double? unitCost,
    String? unitType,
    String? productId,
    String? productName,
    String? operatorId,
    String? operatorName,
    DateTime? timestamp,
    String? notes,
    bool? isSynced,
    String? batchNumber,
  }) {
    return ConsumptionLogModel(
      id: id ?? this.id,
      materialId: materialId ?? this.materialId,
      materialName: materialName ?? this.materialName,
      quantity: quantity ?? this.quantity,
      unitCost: unitCost ?? this.unitCost,
      unitType: unitType ?? this.unitType,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      operatorId: operatorId ?? this.operatorId,
      operatorName: operatorName ?? this.operatorName,
      timestamp: timestamp ?? this.timestamp,
      notes: notes ?? this.notes,
      isSynced: isSynced ?? this.isSynced,
      batchNumber: batchNumber ?? this.batchNumber,
    );
  }

  double get totalCost => quantity * unitCost;
} 