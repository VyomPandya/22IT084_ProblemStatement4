// import 'package:cloud_firestore/cloud_firestore.dart';

enum UnitType {
  kg,
  g,
  l,
  ml,
  piece,
  m,
  cm,
  sqm,
  cubicm,
  pack,
  box,
  roll,
  sheet,
  other
}

class MaterialModel {
  final String id;
  final String name;
  final String? description;
  final String? barcodeOrQR;
  final double unitCost;
  final UnitType unitType;
  final double currentStock;
  final double minimumStock;
  final String? supplierInfo;
  final DateTime lastUpdated;
  final String? imageUrl;
  final bool isActive;
  final String updatedBy;

  MaterialModel({
    required this.id,
    required this.name,
    this.description,
    this.barcodeOrQR,
    required this.unitCost,
    required this.unitType,
    required this.currentStock,
    required this.minimumStock,
    this.supplierInfo,
    required this.lastUpdated,
    this.imageUrl,
    this.isActive = true,
    required this.updatedBy,
  });

  // Factory constructor for demo data
  factory MaterialModel.fromMap(Map<String, dynamic> data) {
    return MaterialModel(
      id: data['id'] ?? '',
      name: data['name'] ?? '',
      description: data['description'],
      barcodeOrQR: data['barcodeOrQR'],
      unitCost: (data['unitCost'] ?? 0.0).toDouble(),
      unitType: _parseUnitType(data['unitType'] ?? 'other'),
      currentStock: (data['currentStock'] ?? 0.0).toDouble(),
      minimumStock: (data['minimumStock'] ?? 0.0).toDouble(),
      supplierInfo: data['supplierInfo'],
      lastUpdated: data['lastUpdated'] != null 
          ? DateTime.parse(data['lastUpdated'].toString()) 
          : DateTime.now(),
      imageUrl: data['imageUrl'],
      isActive: data['isActive'] ?? true,
      updatedBy: data['updatedBy'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'barcodeOrQR': barcodeOrQR,
      'unitCost': unitCost,
      'unitType': unitType.toString().split('.').last,
      'currentStock': currentStock,
      'minimumStock': minimumStock,
      'supplierInfo': supplierInfo,
      'lastUpdated': lastUpdated.toIso8601String(),
      'imageUrl': imageUrl,
      'isActive': isActive,
      'updatedBy': updatedBy,
    };
  }

  MaterialModel copyWith({
    String? id,
    String? name,
    String? description,
    String? barcodeOrQR,
    double? unitCost,
    UnitType? unitType,
    double? currentStock,
    double? minimumStock,
    String? supplierInfo,
    DateTime? lastUpdated,
    String? imageUrl,
    bool? isActive,
    String? updatedBy,
  }) {
    return MaterialModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      barcodeOrQR: barcodeOrQR ?? this.barcodeOrQR,
      unitCost: unitCost ?? this.unitCost,
      unitType: unitType ?? this.unitType,
      currentStock: currentStock ?? this.currentStock,
      minimumStock: minimumStock ?? this.minimumStock,
      supplierInfo: supplierInfo ?? this.supplierInfo,
      lastUpdated: lastUpdated ?? this.lastUpdated,
      imageUrl: imageUrl ?? this.imageUrl,
      isActive: isActive ?? this.isActive,
      updatedBy: updatedBy ?? this.updatedBy,
    );
  }

  bool isLowStock() => currentStock <= minimumStock;

  // Display string for unit type
  String get unitDisplay => unitType.toString().split('.').last;

  static UnitType _parseUnitType(String value) {
    switch (value.toLowerCase()) {
      case 'kg': return UnitType.kg;
      case 'g': return UnitType.g;
      case 'l': return UnitType.l;
      case 'ml': return UnitType.ml;
      case 'piece': return UnitType.piece;
      case 'm': return UnitType.m;
      case 'cm': return UnitType.cm;
      case 'sqm': return UnitType.sqm;
      case 'cubicm': return UnitType.cubicm;
      case 'pack': return UnitType.pack;
      case 'box': return UnitType.box;
      case 'roll': return UnitType.roll;
      case 'sheet': return UnitType.sheet;
      default: return UnitType.other;
    }
  }
} 