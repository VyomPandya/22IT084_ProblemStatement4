// import 'package:cloud_firestore/cloud_firestore.dart';

class ProductModel {
  final String id;
  final String name;
  final String? description;
  final List<MaterialUsage> materialsUsed;
  final double processingCost; // Additional costs (labor, energy, etc.)
  final double? totalCost; // Computed from materials + processing
  final double? suggestedPrice;
  final double? profitMargin; // In percentage
  final String? imageUrl;
  final DateTime createdAt;
  final DateTime lastUpdated;
  final String createdBy;
  final bool isActive;

  ProductModel({
    required this.id,
    required this.name,
    this.description,
    required this.materialsUsed,
    required this.processingCost,
    this.totalCost,
    this.suggestedPrice,
    this.profitMargin,
    this.imageUrl,
    required this.createdAt,
    required this.lastUpdated,
    required this.createdBy,
    this.isActive = true,
  });

  // Factory constructor for demo data
  factory ProductModel.fromMap(Map<String, dynamic> data) {
    // Parse materials used
    List<MaterialUsage> materials = [];
    if (data['materialsUsed'] != null) {
      for (var materialData in data['materialsUsed']) {
        materials.add(MaterialUsage.fromMap(materialData));
      }
    }
    
    return ProductModel(
      id: data['id'] ?? '',
      name: data['name'] ?? '',
      description: data['description'],
      materialsUsed: materials,
      processingCost: (data['processingCost'] ?? 0.0).toDouble(),
      totalCost: data['totalCost']?.toDouble(),
      suggestedPrice: data['suggestedPrice']?.toDouble(),
      profitMargin: data['profitMargin']?.toDouble(),
      imageUrl: data['imageUrl'],
      createdAt: data['createdAt'] != null 
          ? DateTime.parse(data['createdAt'].toString()) 
          : DateTime.now(),
      lastUpdated: data['lastUpdated'] != null 
          ? DateTime.parse(data['lastUpdated'].toString()) 
          : DateTime.now(),
      createdBy: data['createdBy'] ?? '',
      isActive: data['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'materialsUsed': materialsUsed.map((m) => m.toMap()).toList(),
      'processingCost': processingCost,
      'totalCost': calculateTotalCost(),
      'suggestedPrice': calculateSuggestedPrice(),
      'profitMargin': profitMargin,
      'imageUrl': imageUrl,
      'createdAt': createdAt.toIso8601String(),
      'lastUpdated': lastUpdated.toIso8601String(),
      'createdBy': createdBy,
      'isActive': isActive,
    };
  }

  double calculateTotalCost() {
    double materialsCost = materialsUsed.fold(
      0, (sum, material) => sum + (material.quantity * material.unitCost));
    return materialsCost + processingCost;
  }

  double calculateSuggestedPrice() {
    double total = calculateTotalCost();
    return profitMargin != null 
      ? total * (1 + (profitMargin! / 100)) 
      : total * 1.3; // Default 30% margin if not specified
  }

  ProductModel copyWith({
    String? id,
    String? name,
    String? description,
    List<MaterialUsage>? materialsUsed,
    double? processingCost,
    double? totalCost,
    double? suggestedPrice,
    double? profitMargin,
    String? imageUrl,
    DateTime? createdAt,
    DateTime? lastUpdated,
    String? createdBy,
    bool? isActive,
  }) {
    return ProductModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      materialsUsed: materialsUsed ?? this.materialsUsed,
      processingCost: processingCost ?? this.processingCost,
      totalCost: totalCost ?? this.totalCost,
      suggestedPrice: suggestedPrice ?? this.suggestedPrice,
      profitMargin: profitMargin ?? this.profitMargin,
      imageUrl: imageUrl ?? this.imageUrl,
      createdAt: createdAt ?? this.createdAt,
      lastUpdated: lastUpdated ?? this.lastUpdated,
      createdBy: createdBy ?? this.createdBy,
      isActive: isActive ?? this.isActive,
    );
  }
}

class MaterialUsage {
  final String materialId;
  final String materialName;
  final double quantity;
  final double unitCost;
  final String unitType;

  MaterialUsage({
    required this.materialId,
    required this.materialName,
    required this.quantity,
    required this.unitCost,
    required this.unitType,
  });

  factory MaterialUsage.fromMap(Map<String, dynamic> map) {
    return MaterialUsage(
      materialId: map['materialId'] ?? '',
      materialName: map['materialName'] ?? '',
      quantity: (map['quantity'] ?? 0.0).toDouble(),
      unitCost: (map['unitCost'] ?? 0.0).toDouble(),
      unitType: map['unitType'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'materialId': materialId,
      'materialName': materialName,
      'quantity': quantity,
      'unitCost': unitCost,
      'unitType': unitType,
    };
  }

  double get totalCost => quantity * unitCost;
} 