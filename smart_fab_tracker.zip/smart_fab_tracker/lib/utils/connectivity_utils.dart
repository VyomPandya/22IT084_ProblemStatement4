import 'package:flutter/material.dart';

// Simplified mock version for demo
class ConnectivityUtils {
  // Check if the device is currently connected to the internet (mock always returns true)
  static Future<bool> isConnected() async {
    return true;
  }
  
  // Show a snackbar with connectivity status
  static void showConnectivitySnackBar(
    BuildContext context, 
    bool isConnected,
  ) {
    final message = isConnected ? 'Connected to network' : 'No internet connection';
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isConnected ? Colors.green : Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Show an offline indicator widget
  static Widget offlineIndicator() {
    return Container(
      width: double.infinity,
      color: Colors.red,
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cloud_off, color: Colors.white),
          SizedBox(width: 8.0),
          Text(
            'Offline Mode - Changes will sync when reconnected',
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }
} 