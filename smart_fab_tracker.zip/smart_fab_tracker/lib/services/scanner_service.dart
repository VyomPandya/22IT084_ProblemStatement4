import 'package:flutter/material.dart';

import '../models/material_model.dart';
import 'material_service.dart';

// Mock ScannerService for demo purposes
class ScannerService with ChangeNotifier {
  final MaterialService _materialService;
  
  bool _isScanning = false;
  String _scanError = '';
  MaterialModel? _scannedMaterial;

  ScannerService(this._materialService);

  bool get isScanning => _isScanning;
  String get scanError => _scanError;
  MaterialModel? get scannedMaterial => _scannedMaterial;

  // Start the scanning process
  void startScanning() {
    _isScanning = true;
    _scanError = '';
    _scannedMaterial = null;
    notifyListeners();
  }

  // Stop the scanning process
  void stopScanning() {
    _isScanning = false;
    notifyListeners();
  }

  // Reset scan state
  void resetScan() {
    _isScanning = false;
    _scanError = '';
    _scannedMaterial = null;
    notifyListeners();
  }

  // Set error message
  void _setError(String message) {
    _scanError = message;
    _isScanning = false;
    notifyListeners();
  }

  // Simulate scanning result with a barcode value
  Future<MaterialModel?> simulateScan(String barcode) async {
    try {
      if (barcode.isEmpty) {
        _setError('Invalid barcode data');
        return null;
      }

      // Add a delay to simulate scanning
      await Future.delayed(Duration(milliseconds: 500));
      
      // Look up the material by barcode
      final material = _materialService.getMaterialByBarcode(barcode);
      
      if (material == null) {
        _setError('No material found with barcode: $barcode');
        return null;
      }

      // Found a valid material
      _scannedMaterial = material;
      _isScanning = false;
      _scanError = '';
      notifyListeners();
      
      return material;
    } catch (e) {
      _setError('Error processing barcode: $e');
      return null;
    }
  }

  // Process a manually entered barcode
  Future<MaterialModel?> processManualBarcode(String barcode) async {
    try {
      if (barcode.isEmpty) {
        _setError('Please enter a valid barcode');
        return null;
      }

      // Simulate network delay
      await Future.delayed(Duration(milliseconds: 300));

      // In a real app, this would make a database query
      // For this demo, we'll use predefined barcodes
      final material = _materialService.getMaterialByBarcode(barcode);
      
      if (material == null) {
        _setError('No material found with barcode: $barcode');
        return null;
      }

      // Found a valid material
      _scannedMaterial = material;
      _scanError = '';
      notifyListeners();
      
      return material;
    } catch (e) {
      _setError('Error processing barcode: $e');
      return null;
    }
  }

  // Handle the case where material is selected directly rather than scanned
  void setSelectedMaterial(MaterialModel material) {
    _scannedMaterial = material;
    _isScanning = false;
    _scanError = '';
    notifyListeners();
  }

  // Generate a QR code for a material (for admin printing purposes)
  String generateQRCodeData(MaterialModel material) {
    // Create a data string for the QR code
    // This could be just the barcode/QR value, or a structured JSON with more data
    if (material.barcodeOrQR != null && material.barcodeOrQR!.isNotEmpty) {
      return material.barcodeOrQR!;
    } else {
      // If no barcode exists, use the material ID as the code
      return material.id;
    }
  }
} 