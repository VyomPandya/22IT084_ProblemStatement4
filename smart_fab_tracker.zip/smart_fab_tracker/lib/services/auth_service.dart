import 'package:flutter/material.dart';
import '../models/user_model.dart';

// Mock AuthService for demo purposes without Firebase
class AuthService with ChangeNotifier {
  UserModel? _currentUser;
  bool _isOfflineMode = false;

  // Get current user info
  UserModel? get currentUser => _currentUser;
  
  // Check if user is logged in
  bool get isLoggedIn => _currentUser != null;
  
  // Check if user is in offline mode
  bool get isOfflineMode => _isOfflineMode;

  // Initialize the auth service with mock data
  Future<void> init() async {
    // Create mock admin user for demo
    _currentUser = UserModel(
      id: '1',
      name: 'Admin User',
      email: 'admin@smartfab.com',
      role: UserRole.admin,
      createdAt: DateTime.now(),
      lastLogin: DateTime.now(),
      isActive: true,
    );
    notifyListeners();
  }

  // Sign in with email and password
  Future<UserModel?> signIn(String email, String password) async {
    try {
      // Mock authentication - accept any credentials for demo
      await Future.delayed(Duration(seconds: 1)); // Simulate network delay
      
      if (email.contains('admin')) {
        _currentUser = UserModel(
          id: '1',
          name: 'Admin User',
          email: email,
          role: UserRole.admin,
          createdAt: DateTime.now(),
          lastLogin: DateTime.now(),
          isActive: true,
        );
      } else {
        _currentUser = UserModel(
          id: '2',
          name: 'Operator User',
          email: email,
          role: UserRole.operator,
          createdAt: DateTime.now(),
          lastLogin: DateTime.now(),
          isActive: true,
        );
      }
      
      notifyListeners();
      return _currentUser;
    } catch (e) {
      print('Mock sign in error: $e');
      rethrow;
    }
  }

  // Offline login mode (simplified for demo)
  Future<UserModel?> offlineLogin(String email, String password) async {
    _isOfflineMode = true;
    
    // Create mock user for offline mode
    _currentUser = UserModel(
      id: '3',
      name: 'Offline User',
      email: email,
      role: UserRole.operator,
      createdAt: DateTime.now(),
      isActive: true,
    );
    
    notifyListeners();
    return _currentUser;
  }

  // Sign out
  Future<void> signOut() async {
    _currentUser = null;
    _isOfflineMode = false;
    notifyListeners();
  }

  // Check if user has admin rights
  bool hasAdminRights() {
    return _currentUser != null && _currentUser!.isAdmin();
  }

  // Get all users (mocked)
  Future<List<UserModel>> getAllUsers() async {
    return [
      UserModel(
        id: '1',
        name: 'Admin User',
        email: 'admin@smartfab.com',
        role: UserRole.admin,
        createdAt: DateTime.now().subtract(Duration(days: 30)),
        lastLogin: DateTime.now(),
        isActive: true,
      ),
      UserModel(
        id: '2',
        name: 'John Operator',
        email: 'john@smartfab.com',
        role: UserRole.operator,
        createdAt: DateTime.now().subtract(Duration(days: 20)),
        lastLogin: DateTime.now().subtract(Duration(days: 1)),
        isActive: true,
      ),
      UserModel(
        id: '3',
        name: 'Sarah Operator',
        email: 'sarah@smartfab.com',
        role: UserRole.operator,
        createdAt: DateTime.now().subtract(Duration(days: 15)),
        lastLogin: DateTime.now().subtract(Duration(hours: 5)),
        isActive: true,
      ),
    ];
  }
} 