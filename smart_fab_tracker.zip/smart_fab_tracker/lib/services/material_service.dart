import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/material_model.dart';
import 'auth_service.dart';

class MaterialService with ChangeNotifier {
  final AuthService _authService;
  
  List<MaterialModel> _materials = [];
  bool _isLoading = false;
  bool _hasError = false;
  String _errorMessage = '';

  MaterialService(this._authService) {
    _loadMockMaterials();
  }

  // Getters
  List<MaterialModel> get materials => _materials;
  bool get isLoading => _isLoading;
  bool get hasError => _hasError;
  String get errorMessage => _errorMessage;

  // Load mock materials
  Future<void> _loadMockMaterials() async {
    _isLoading = true;
    _hasError = false;
    notifyListeners();

    try {
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Create mock materials
      _materials = [
        MaterialModel(
          id: '1',
          name: 'Steel Plate 5mm',
          description: 'High quality carbon steel plate, 5mm thickness',
          barcodeOrQR: 'STEEL-5MM-001',
          unitCost: 45.50,
          unitType: UnitType.kg,
          currentStock: 350.0,
          minimumStock: 100.0,
          supplierInfo: 'MetalWorks Inc.',
          lastUpdated: DateTime.now().subtract(const Duration(days: 5)),
          updatedBy: 'admin',
        ),
        MaterialModel(
          id: '2',
          name: 'Aluminum Sheet 2mm',
          description: 'Lightweight aluminum sheet, 2mm thickness',
          barcodeOrQR: 'ALU-2MM-002',
          unitCost: 32.75,
          unitType: UnitType.kg,
          currentStock: 150.0,
          minimumStock: 50.0,
          supplierInfo: 'LightMetals Co.',
          lastUpdated: DateTime.now().subtract(const Duration(days: 2)),
          updatedBy: 'admin',
        ),
        MaterialModel(
          id: '3',
          name: 'Copper Wire 12AWG',
          description: 'Pure copper wire, 12 AWG',
          barcodeOrQR: 'COPPER-12AWG-003',
          unitCost: 8.99,
          unitType: UnitType.m,
          currentStock: 450.0,
          minimumStock: 200.0,
          supplierInfo: 'ElectroParts Ltd.',
          lastUpdated: DateTime.now().subtract(const Duration(days: 7)),
          updatedBy: 'john',
        ),
        MaterialModel(
          id: '4',
          name: 'PVC Pipe 2in',
          description: 'Standard PVC pipe, 2 inch diameter',
          barcodeOrQR: 'PVC-2IN-004',
          unitCost: 12.50,
          unitType: UnitType.m,
          currentStock: 120.0,
          minimumStock: 40.0,
          supplierInfo: 'PlumbingSupplies Inc.',
          lastUpdated: DateTime.now().subtract(const Duration(days: 10)),
          updatedBy: 'admin',
        ),
        MaterialModel(
          id: '5',
          name: 'Rubber Sheet 3mm',
          description: 'Industrial rubber sheet, 3mm thickness',
          barcodeOrQR: 'RUBBER-3MM-005',
          unitCost: 18.25,
          unitType: UnitType.sqm,
          currentStock: 45.0,
          minimumStock: 20.0,
          supplierInfo: 'RubberWorks Co.',
          lastUpdated: DateTime.now().subtract(const Duration(days: 3)),
          updatedBy: 'sarah',
        ),
      ];
      
      _isLoading = false;
      _hasError = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _hasError = true;
      _errorMessage = 'Failed to load materials: $e';
      notifyListeners();
    }
  }

  // Get a material by ID
  MaterialModel? getMaterialById(String id) {
    try {
      return _materials.firstWhere((material) => material.id == id);
    } catch (e) {
      return null;
    }
  }

  // Get a material by barcode
  MaterialModel? getMaterialByBarcode(String barcode) {
    try {
      return _materials.firstWhere(
        (material) => material.barcodeOrQR == barcode,
      );
    } catch (e) {
      return null;
    }
  }

  // Add a new material
  Future<MaterialModel?> addMaterial(MaterialModel material) async {
    try {
      _isLoading = true;
      notifyListeners();
      
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      // In a real app, would save to Firestore
      // For the demo, just add to local list
      final newMaterial = material.copyWith(
        id: const Uuid().v4(),
        lastUpdated: DateTime.now(),
        updatedBy: _authService.currentUser?.id ?? 'unknown',
      );
      
      _materials.add(newMaterial);
      
      _isLoading = false;
      notifyListeners();
      return newMaterial;
    } catch (e) {
      _isLoading = false;
      _hasError = true;
      _errorMessage = 'Failed to add material: $e';
      notifyListeners();
      return null;
    }
  }

  // Update material
  Future<bool> updateMaterial(MaterialModel material) async {
    try {
      _isLoading = true;
      notifyListeners();
      
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Find the material index
      final index = _materials.indexWhere((m) => m.id == material.id);
      if (index < 0) {
        _hasError = true;
        _errorMessage = 'Material not found';
        _isLoading = false;
        notifyListeners();
        return false;
      }
      
      // Update material with new timestamp
      _materials[index] = material.copyWith(
        lastUpdated: DateTime.now(),
        updatedBy: _authService.currentUser?.id ?? 'unknown',
      );
      
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _hasError = true;
      _errorMessage = 'Failed to update material: $e';
      notifyListeners();
      return false;
    }
  }

  // Delete material
  Future<bool> deleteMaterial(String id) async {
    try {
      _isLoading = true;
      notifyListeners();
      
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Find the material index
      final index = _materials.indexWhere((m) => m.id == id);
      if (index < 0) {
        _hasError = true;
        _errorMessage = 'Material not found';
        _isLoading = false;
        notifyListeners();
        return false;
      }
      
      // Remove from list
      _materials.removeAt(index);
      
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _hasError = true;
      _errorMessage = 'Failed to delete material: $e';
      notifyListeners();
      return false;
    }
  }

  // Update stock levels after consumption
  Future<bool> updateStockAfterConsumption(String materialId, double quantity) async {
    try {
      // Get the material
      final material = getMaterialById(materialId);
      if (material == null) {
        _hasError = true;
        _errorMessage = 'Material not found';
        notifyListeners();
        return false;
      }
      
      // Check if we have enough stock
      if (material.currentStock < quantity) {
        _hasError = true;
        _errorMessage = 'Not enough stock available';
        notifyListeners();
        return false;
      }
      
      // Update the stock
      return updateMaterial(material.copyWith(
        currentStock: material.currentStock - quantity,
      ));
    } catch (e) {
      _hasError = true;
      _errorMessage = 'Failed to update stock: $e';
      notifyListeners();
      return false;
    }
  }

  // Get low stock materials
  List<MaterialModel> getLowStockMaterials() {
    return _materials.where((m) => m.isLowStock()).toList();
  }

  // Clear error state
  void clearError() {
    _hasError = false;
    _errorMessage = '';
    notifyListeners();
  }
} 