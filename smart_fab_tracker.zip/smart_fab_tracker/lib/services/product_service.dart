import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/product_model.dart';
import '../models/material_model.dart';
import 'auth_service.dart';

// Mock ProductService for demo purposes without Firebase
class ProductService with ChangeNotifier {
  final AuthService _authService;
  
  List<ProductModel> _products = [];
  bool _isLoading = false;
  bool _hasError = false;
  String _errorMessage = '';

  ProductService(this._authService) {
    _loadMockProducts();
  }

  // Getters
  List<ProductModel> get products => _products;
  bool get isLoading => _isLoading;
  bool get hasError => _hasError;
  String get errorMessage => _errorMessage;

  // Load mock products
  Future<void> _loadMockProducts() async {
    _isLoading = true;
    _hasError = false;
    notifyListeners();

    try {
      // Simulate network delay
      await Future.delayed(Duration(milliseconds: 800));
      
      // Create mock products
      _products = [
        ProductModel(
          id: '1',
          name: 'Metal Cabinet',
          description: 'Standard 2-door metal cabinet',
          materialsUsed: [
            MaterialUsage(
              materialId: '1',
              materialName: 'Steel Plate 5mm',
              quantity: 4.0,
              unitCost: 45.50,
              unitType: 'sqm',
            ),
            MaterialUsage(
              materialId: '4',
              materialName: 'Stainless Steel Tube 1.5"',
              quantity: 8.0,
              unitCost: 12.99,
              unitType: 'm',
            ),
          ],
          processingCost: 125.0,
          createdAt: DateTime.now().subtract(Duration(days: 45)),
          lastUpdated: DateTime.now().subtract(Duration(days: 10)),
          createdBy: 'admin',
          profitMargin: 30.0,
        ),
        ProductModel(
          id: '2',
          name: 'Electric Fan',
          description: 'Ceiling mounted electric fan',
          materialsUsed: [
            MaterialUsage(
              materialId: '5',
              materialName: 'Electric Motor 240V',
              quantity: 1.0,
              unitCost: 89.99,
              unitType: 'piece',
            ),
            MaterialUsage(
              materialId: '3',
              materialName: 'Copper Wire 12AWG',
              quantity: 5.0,
              unitCost: 2.35,
              unitType: 'm',
            ),
          ],
          processingCost: 45.0,
          createdAt: DateTime.now().subtract(Duration(days: 30)),
          lastUpdated: DateTime.now().subtract(Duration(days: 5)),
          createdBy: 'admin',
          profitMargin: 40.0,
        ),
        ProductModel(
          id: '3',
          name: 'Aluminum Shelf',
          description: 'Lightweight aluminum shelf unit',
          materialsUsed: [
            MaterialUsage(
              materialId: '2',
              materialName: 'Aluminum Sheet 2mm',
              quantity: 3.0,
              unitCost: 32.75,
              unitType: 'sqm',
            ),
          ],
          processingCost: 60.0,
          createdAt: DateTime.now().subtract(Duration(days: 20)),
          lastUpdated: DateTime.now().subtract(Duration(days: 20)),
          createdBy: 'admin',
          profitMargin: 25.0,
        ),
      ];

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _hasError = true;
      _errorMessage = 'Failed to load products: $e';
      notifyListeners();
      print('Error loading products: $e');
    }
  }

  // Get product by ID
  ProductModel? getProductById(String id) {
    try {
      return _products.firstWhere((p) => p.id == id);
    } catch (e) {
      return null;
    }
  }

  // Add a new product (Admin only)
  Future<ProductModel?> addProduct(ProductModel product) async {
    try {
      if (!_authService.hasAdminRights()) {
        throw Exception('Only admins can add products');
      }

      // Generate a new ID if not provided
      final id = product.id.isEmpty ? const Uuid().v4() : product.id;
      final now = DateTime.now();
      
      final newProduct = product.copyWith(
        id: id,
        createdAt: now,
        lastUpdated: now,
        createdBy: _authService.currentUser?.id ?? '',
        // Calculate costs
        totalCost: product.calculateTotalCost(),
        suggestedPrice: product.calculateSuggestedPrice(),
      );

      // Add to local list 
      _products.add(newProduct);
      
      notifyListeners();
      return newProduct;
    } catch (e) {
      _hasError = true;
      _errorMessage = 'Failed to add product: $e';
      notifyListeners();
      print('Error adding product: $e');
      rethrow;
    }
  }

  // Update an existing product (Admin only)
  Future<void> updateProduct(ProductModel product) async {
    try {
      if (!_authService.hasAdminRights()) {
        throw Exception('Only admins can update products');
      }

      final updatedProduct = product.copyWith(
        lastUpdated: DateTime.now(),
        // Recalculate costs
        totalCost: product.calculateTotalCost(),
        suggestedPrice: product.calculateSuggestedPrice(),
      );

      // Update in local list
      final index = _products.indexWhere((p) => p.id == product.id);
      if (index >= 0) {
        _products[index] = updatedProduct;
      } else {
        throw Exception('Product not found');
      }
      
      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorMessage = 'Failed to update product: $e';
      notifyListeners();
      print('Error updating product: $e');
      rethrow;
    }
  }

  // Delete a product (Admin only)
  Future<void> deleteProduct(String productId) async {
    try {
      if (!_authService.hasAdminRights()) {
        throw Exception('Only admins can delete products');
      }

      // Remove from local list
      _products.removeWhere((p) => p.id == productId);
      
      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorMessage = 'Failed to delete product: $e';
      notifyListeners();
      print('Error deleting product: $e');
      rethrow;
    }
  }

  // Calculate profit margin given cost and selling price
  double calculateProfitMargin(double cost, double sellingPrice) {
    if (cost <= 0 || sellingPrice <= 0) return 0;
    return ((sellingPrice - cost) / cost) * 100;
  }

  // Calculate selling price given cost and profit margin %
  double calculateSellingPrice(double cost, double profitMarginPercentage) {
    if (cost <= 0) return 0;
    return cost * (1 + (profitMarginPercentage / 100));
  }
} 