package com.example.smart_fab_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
